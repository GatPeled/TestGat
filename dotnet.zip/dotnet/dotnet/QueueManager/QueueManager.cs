﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Configuration;
using System.Text;

namespace QueueManager
{
    class QueueManager
    {
        static void Main(string[] args)
        {
            var factory = new ConnectionFactory() { HostName = "localhost" };
            using(var connection = factory.CreateConnection())
            using(var channel = connection.CreateModel())
            {
                using (var channelSend = connection.CreateModel())
                {
                    channel.QueueDeclare(queue: "Person", durable: false, exclusive: false, autoDelete: false, arguments: null);
                    channelSend.QueueDeclare(queue: "PersonNoAge", durable: false, exclusive: false, autoDelete: false, arguments: null);

                    Console.WriteLine(" [*] Waiting for messages.");

                    var consumer = new EventingBasicConsumer(channel);
                    consumer.Received += (model, ea) =>
                    {
                        var body = ea.Body.ToArray();
                        var message = Encoding.UTF8.GetString(body);
                        Console.WriteLine(" [x] Received {0}", message);
                        var decryptedMassge = message.Decrypt(ConfigurationManager.AppSettings["key"]);

                        Console.WriteLine(" [x] Received {0}", decryptedMassge);
                        var p = JsonConvert.DeserializeObject<Person>(decryptedMassge);
                        p.Age = null;

                        message = JsonConvert.SerializeObject(p);
                        var encryptedMassge = message.Encrypt(ConfigurationManager.AppSettings["key"]);
                        body = Encoding.UTF8.GetBytes(encryptedMassge);

                        channelSend.BasicPublish(exchange: "", routingKey: "PersonNoAge", basicProperties: null, body: body);
                    };
                    channel.BasicConsume(queue: "Person", autoAck: true, consumer: consumer);

                    Console.WriteLine(" Press [enter] to exit.");
                    Console.ReadLine();
                }
            }
        }
    }
}
