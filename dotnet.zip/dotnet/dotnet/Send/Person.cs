using System;

[Serializable]
public class Person
{
    public string Name { get; set; }
    public DateTime Date { get; set; }
    public int Age { get; set; }
    public string Occupation { get; set; }
}