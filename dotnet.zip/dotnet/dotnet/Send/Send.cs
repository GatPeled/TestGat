using System;
using RabbitMQ.Client;
using System.Text;
using Newtonsoft.Json;
using System.Configuration;

class Send
{
    public static void Main()
    {
        var person = new Person()
        {
            Name = "Gat",
            Date = DateTime.Now,
            Age = 10,
            Occupation = "Programmer"
        };

        var factory = new ConnectionFactory() { HostName = "localhost" };
        using(var connection = factory.CreateConnection())
        using(var channel = connection.CreateModel())
        {
            channel.QueueDeclare(queue: "Person", durable: false, exclusive: false, autoDelete: false, arguments: null);
            for (int i = 0; i < 10; i++)
            {
                person.Age = i; 
                string message = JsonConvert.SerializeObject(person);
                
                var encryptedMassage = message.Encrypt(ConfigurationManager.AppSettings["key"]);
                var body = Encoding.UTF8.GetBytes(encryptedMassage);

                channel.BasicPublish(exchange: "", routingKey: "Person", basicProperties: null, body: body);
                Console.WriteLine(" [x] Sent {0}", message);
            }
        }

        Console.WriteLine(" Press [enter] to exit.");
        Console.ReadLine();
    }
}
